﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Otp : System.Web.UI.Page
{
    string constr = ConfigurationManager.ConnectionStrings["dbConnection"].ToString();
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string Type, UserID;

    protected void Page_Load(object sender, EventArgs e)
    {
        Type = Session["type"].ToString();
        UserID = Session["user_id"].ToString();
    }

    protected void btnVerify_Click(object sender, EventArgs e)
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("usp_VerifyOtp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserID", UserID);
            cmd.Parameters.AddWithValue("@Otp", txtOtp.Text);
            cmd.Parameters.AddWithValue("@Type", Type);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if(dt.Rows.Count > 0)
            {
                int Status = Convert.ToInt32(dt.Rows[0]["Status"].ToString());
                string Message = dt.Rows[0]["Message"].ToString();

                if (Status.Equals(200))
                {
                    if (Type.Equals("1"))
                        Response.Redirect("Admin/Home.aspx");
                    else
                        Response.Redirect("Users/Home.aspx");
                }
                else
                    Response.Write("<script>alert('"+Message+"')</script>");
            }
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
}