﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Security.Cryptography;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Net.Mail;
using System.Diagnostics;



public partial class Upload_File : System.Web.UI.Page
{
    public int i, j, k;

    public static string fileName;
    public static string fileExtension;
    public static string file_path;
    public static string hashData;

    //Build the File Path for the original (input) and the encrypted (output) file.
    public static string input;
    public static string file_name1;
    public static string output1, output;
    public static string select_id;

    public static byte[] iv;
    public static byte[] encryptedMessage = null;
    public static string combindedString;
    public static byte[] bobKey;
    public static byte[] aliceKey;
    public static string data, data1, data2;
    string publicPrivateKeyXML;
    string publicOnlyKeyXML;
    public static string cs = ConfigurationManager.ConnectionStrings["dbConnection"].ConnectionString;
    public SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["a_id"] == "")
        {
            Response.Redirect("Login.aspx?msg=logout");

        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            conn = new SqlConnection(cs);
            Stopwatch objWatch = new Stopwatch();
            objWatch.Start();

            string fileName = Path.GetFileNameWithoutExtension(FileUpload1.PostedFile.FileName);
            string fileExtension = Path.GetExtension(FileUpload1.PostedFile.FileName);
            string file_path = Path.GetFileName(FileUpload1.PostedFile.FileName);
           


                //Build the File Path for the original (input) and the encrypted (output) file.
                string input = Server.MapPath("../Files/") + fileName + fileExtension;
                string file_name1 = fileName + "_enc1" + fileExtension;
                //string file_name2 = fileName + "_enc2" + fileExtension;
                //string file_name3 = fileName + "_enc3" + fileExtension;
                //string output1 = Server.MapPath("../Files/" + file_name1);
                //string output2 = Server.MapPath("../Files/" + file_name2);
                //string output3 = Server.MapPath("../Files/" + file_name3);

                string output1 = Server.MapPath("../Files/") + fileName + "_enc1" + fileExtension;
                string output = Server.MapPath("../Files/") + fileName + "_enc" + fileExtension;
                //Save the Input File, Encrypt it and save the encrypted file in output path.
                FileUpload1.SaveAs(input);

                SqlDataAdapter _adp_R = new SqlDataAdapter("select Top(1)* from auto_keys order by NEWID()", Database.cs);
                DataTable _dtr = new DataTable();
                _adp_R.Fill(_dtr);
                string encryptedkey;
                if (_dtr.Rows.Count > 0)
                {
                    encryptedkey = _dtr.Rows[0]["key_value"].ToString();
                }
                else
                {
                    encryptedkey = "0";
                }

                string key1 = encryptedkey;
                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(key1);

                Stream inputStream = FileUpload1.PostedFile.InputStream;
                Byte[] data;

                using (var streamReader = new MemoryStream())
                {
                    inputStream.CopyTo(streamReader);
                    data = streamReader.ToArray();
                    data1 = Convert.ToBase64String(data);
                    data2 = Encoding.UTF8.GetString(data, 0, data.Length);
                }

                byte[] bobPrivateKey;
                byte[] iv;
                string private_key = "";


                using (var alice = new ECDiffieHellmanCng())
                {
                    byte[] encryptedMessage;

                    alice.KeyDerivationFunction = ECDiffieHellmanKeyDerivationFunction.Hash;
                    alice.HashAlgorithm = CngAlgorithm.Sha256;
                    Alice.alicePublicKey = alice.PublicKey.ToByteArray();
                    var bob = new Bob();
                    CngKey k = CngKey.Import(bob.bobPublicKey, CngKeyBlobFormat.EccPublicBlob);
                    byte[] aliceKey =
                        alice.DeriveKeyMaterial(CngKey.Import(bob.bobPublicKey, CngKeyBlobFormat.EccPublicBlob));
                    Alice.Send(aliceKey, data, out encryptedMessage, out iv);
                    bobPrivateKey = bob.bobKey;


                    //  bobPrivateKey = buffer;
                    string result = Encoding.UTF8.GetString(iv);
                    using (Stream file = File.OpenWrite(output))
                    {
                        file.Write(encryptedMessage, 0, encryptedMessage.Length);
                    }
                    byte[] size = File.ReadAllBytes(output);
                    
                   
                }


                hashData = performHash(data2);
                Encrypt_AES(key1, output, output1);

                objWatch.Stop();
                var time = objWatch.ElapsedMilliseconds;

                using (
                    SqlCommand cmd =
                        new SqlCommand(
                            "insert into file_master (file_path,key_value,File_Key,IV,file_name,hash) values(@file_path,@key_value,@key,@iv,@file_name,@hash)",
                            conn))
                {
                    cmd.Parameters.AddWithValue("@file_name", file_path);
                    cmd.Parameters.AddWithValue("@file_path", file_name1);
                    cmd.Parameters.AddWithValue("@key_value", key1);
                    cmd.Parameters.AddWithValue("@key", Convert.ToBase64String(bobPrivateKey));
                    cmd.Parameters.AddWithValue("@iv", Convert.ToBase64String(iv));
                    cmd.Parameters.AddWithValue("@hash", hashData);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }

                //string query = "Insert Into File_Info values('" + file_path + "','" + encryptedkey+"')";
                //Database.InsertData_direct(query);
                Response.Redirect("Manage Files.aspx?msg=add&time="+time);

            }

        }
  
    private void Encrypt_AES(string key, string inputFilePath, string outputfilePath)
    {
        string EncryptionKey = key;
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (FileStream fsOutput = new FileStream(outputfilePath, FileMode.Create))
            {
                using (CryptoStream cs = new CryptoStream(fsOutput, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    using (FileStream fsInput = new FileStream(inputFilePath, FileMode.Open))
                    {
                        int data;
                        while ((data = fsInput.ReadByte()) != -1)
                        {
                            cs.WriteByte((byte)data);
                        }
                    }
                }
            }
        }
    }


    private string performHash(string data)
    {
        byte[] bytes = Encoding.Unicode.GetBytes(data);
        SHA256Managed hashstring = new SHA256Managed();
        byte[] hash = hashstring.ComputeHash(bytes);
        string hashString = string.Empty;
        foreach (byte x in hash)
        {
            hashString += String.Format("{0:x2}", x);
        }
        return hashString;
    }

    private List<string> stopword(List<string> token)
    {
        string[] stopword = new string[1000];
        int m = stopword.GetLength(0);
        int n = token.Count();
        string[] _ceksplit = new string[n];
        bool sama = true;
        int jmlh = 0;
        FileStream sr = new FileStream(Server.MapPath("../Admin/stopwords.txt"), FileMode.Open);
        StreamReader str = new StreamReader(sr);
        int a = 0;
        while (!str.EndOfStream)
        {
            stopword[a] = str.ReadLine();
            a++;
        }
        sr.Close();
        str.Close();
        for (int j = 0; j < n; j++)
        {
            sama = true;
            for (int k = 0; k < m; k++)
            {
                if (token[j] == stopword[k])
                    sama = false;
            }
            if (sama != false)
            {
                _ceksplit[j] = token[j];
                jmlh++;
            }
        }
        List<string> words = new List<string>();
        for (int l = 0; l < n; l++)
        {
            if (_ceksplit[l] != null)
            {
                words.Add(_ceksplit[l]);
            }
        }
        return words;
    }

    private List<string> tokenizing(string isifile)
    {
        isifile = isifile.ToLower();
        char[] pemisah = new char[] { '~', '}', '{', '|', '*', ':', '\\', '_', '[', ']', '/', ';', '<', '>', ' ', '-', '=', '+', '.', ',', ',', '"', '!', '?', '@', '#', '$', '%', '^', '&', '(', ')', '\r', '\n', '\t', '\v', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };
        List<string> token = isifile.Split(pemisah, StringSplitOptions.RemoveEmptyEntries).ToList();
        return token;
    }

}
