﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    string constr = ConfigurationManager.ConnectionStrings["dbConnection"].ToString();
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["msg"] == "logout")
        {
            Session.Abandon();
            Session["a_id"] = "";
            Alert.Show("You Are Logout Successfully");
        }
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string query = "select * from admin_login where username='" + txtUsername.Text + "' and password='" + txtPassword.Text + "'";
        DataTable dt = Database.Getdata(query);
        if (dt.Rows.Count > 0)
        {
            string admin_id = Convert.ToString(dt.Rows[0]["admin_id"]);

            Random r = new Random();
            int Otp = r.Next(11111, 99999);

            con = new SqlConnection(constr);
            cmd = new SqlCommand("select * from trnOtp where UserID = @UserID and Type = 2", con);
            cmd.Parameters.AddWithValue("@UserID", admin_id);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                cmd = new SqlCommand("update trnOtp set [Otp] = @Otp, [GeneratedOn] = getdate() where UserID = @UserID", con);
            }
            else
            {
                cmd = new SqlCommand("insert into trnOtp (UserID,Otp,GeneratedOn,Type) values (@UserID,@Otp,getdate(),1)", con);
            }

            cmd.Parameters.AddWithValue("@UserID", admin_id);
            cmd.Parameters.AddWithValue("@Otp", Otp);
            if (con.State != ConnectionState.Open)
                con.Open();
            int result = cmd.ExecuteNonQuery();
            if (result == 1)
            {

                MailMessage mail1 = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
                mail1.From = new MailAddress("vamsiambati203@gmail.com");
                mail1.To.Add("vamsiambati203@gmail.com");
                mail1.Subject = "OTP for Login";
                mail1.Body = "Your OTP: " + Otp + "\n" +
                              "Your OTP will be valid for 5 minutes";
                SmtpServer.Port = 587;
                SmtpServer.EnableSsl = true;
                SmtpServer.Credentials = new System.Net.NetworkCredential("vamsiambati203@gmail.com", "nqomyvmnmcnacjle");
                SmtpServer.Send(mail1);

               WebRequest MyRssRequest = WebRequest.Create("https://www.fast2sms.com/dev/bulkV2?authorization=YSlE47CHXzeWpjy51NZb2Rmkx9AhB8TdDfKoi3qnGrF6gLVI0vIpozyXD97fFHu2RMKTBeldxbWLi1va&route=v3&sender_id=FTWSMS&language=english&flash=0&numbers="+8074259123+" &message=Your OTP is  " + Otp +". It will expire in 5 mins");
                WebResponse MyRssResponse = MyRssRequest.GetResponse();
                Stream MyRssStream = MyRssResponse.GetResponseStream();

                Response.Write("<script>alert('Please check your mail')</script>");

                Session["a_id"] = admin_id;
                Session["user_id"] = admin_id;
                Session["type"] = 1;
                Response.Redirect("../Otp.aspx");
            }
            else
                Response.Write("<script>alert('Something went wrong')</script>");



        }
        else
        {
            Alert.Show("Invalid Username or Password");
            txtUsername.Text = "";
            txtPassword.Text = "";

        }

    }

      //protected static string fileGetContents(string fileName)
      //  {
      //      var sContents = string.Empty;
      //      var me = string.Empty;
      //      try
      //      {
      //          if (fileName.ToLower().IndexOf("http:") > -1)
      //          {
      //              var wc = new WebClient();
      //              var response = wc.DownloadData(fileName);
      //              sContents = Encoding.ASCII.GetString(response);

      //          }
      //          else
      //          {
      //              var sr = new StreamReader(fileName);
      //              sContents = sr.ReadToEnd();
      //              sr.Close();
      //          }
      //      }
      //      catch { sContents = "unable to connect to server "; }
      //      return sContents;
      //  }
    }
