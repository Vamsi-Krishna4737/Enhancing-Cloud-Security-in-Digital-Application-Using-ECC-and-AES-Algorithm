USE [master]
GO
/****** Object:  Database [ENC_DEC_AES_ECC]    Script Date: 05-03-2023 20:00:41 ******/
CREATE DATABASE [ENC_DEC_AES_ECC]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'ENC_DEC_AES_ECC', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS01\MSSQL\DATA\ENC_DEC_AES_ECC.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'ENC_DEC_AES_ECC_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS01\MSSQL\DATA\ENC_DEC_AES_ECC_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [ENC_DEC_AES_ECC].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET ARITHABORT OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET  DISABLE_BROKER 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET  MULTI_USER 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET DB_CHAINING OFF 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET QUERY_STORE = OFF
GO
USE [ENC_DEC_AES_ECC]
GO
/****** Object:  Table [dbo].[admin_login]    Script Date: 05-03-2023 20:00:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[admin_login](
	[admin_id] [int] IDENTITY(1,1) NOT NULL,
	[username] [nvarchar](50) NULL,
	[password] [nvarchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[auto_keys]    Script Date: 05-03-2023 20:00:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[auto_keys](
	[key_id] [int] IDENTITY(1,1) NOT NULL,
	[key_value] [nvarchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[File_Info]    Script Date: 05-03-2023 20:00:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[File_Info](
	[file_id] [int] IDENTITY(1,1) NOT NULL,
	[file_name] [nvarchar](50) NULL,
	[key1] [nvarchar](50) NULL,
	[cloud1_file_path] [nvarchar](max) NULL,
	[cloud2_file_path] [nvarchar](max) NULL,
	[cloud3_file_path] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[File_Master]    Script Date: 05-03-2023 20:00:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[File_Master](
	[file_id] [int] IDENTITY(1,1) NOT NULL,
	[file_path] [nvarchar](max) NULL,
	[key_value] [nvarchar](50) NULL,
	[file_name] [nvarchar](max) NULL,
	[File_key] [nvarchar](max) NULL,
	[IV] [nvarchar](max) NULL,
	[Hash] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FileLog]    Script Date: 05-03-2023 20:00:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FileLog](
	[logId] [int] IDENTITY(1,1) NOT NULL,
	[User_id] [int] NULL,
	[share_id] [int] NULL,
	[LogType] [int] NULL,
	[LogDate] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Share_Master]    Script Date: 05-03-2023 20:00:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Share_Master](
	[share_id] [int] IDENTITY(1,1) NOT NULL,
	[file_name] [nvarchar](50) NULL,
	[username] [nvarchar](50) NULL,
	[cloud_id] [nvarchar](50) NULL,
	[fid] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[trnOtp]    Script Date: 05-03-2023 20:00:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[trnOtp](
	[OTPID] [int] IDENTITY(1,1) NOT NULL,
	[UserID] [int] NULL,
	[OTP] [int] NULL,
	[GeneratedOn] [datetime] NULL,
	[Type] [tinyint] NULL,
PRIMARY KEY CLUSTERED 
(
	[OTPID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[User_Master]    Script Date: 05-03-2023 20:00:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[User_Master](
	[user_id] [int] IDENTITY(1,1) NOT NULL,
	[full_name] [nvarchar](50) NULL,
	[contact_no] [nvarchar](50) NULL,
	[email_id] [nvarchar](50) NULL,
	[address] [nvarchar](max) NULL,
	[password] [nvarchar](50) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[admin_login] ON 
GO
INSERT [dbo].[admin_login] ([admin_id], [username], [password]) VALUES (1, N'admin', N'admin')
GO
SET IDENTITY_INSERT [dbo].[admin_login] OFF
GO
SET IDENTITY_INSERT [dbo].[auto_keys] ON 
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (1, N'HhOF5M4iSBDqH9t5')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (2, N'RSsXECK53QMENjwx')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (3, N'KezM2QyHrzSykUG8')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (4, N'NZoDpCFtMvp4zh7c')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (5, N'hTAN4Pd4pLdbpWek')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (6, N'I4y8UvLFTbXxvnwz')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (7, N'n7B1DuiIN0m6ZxIH')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (8, N'WP3A9IVt9SR0uKtX')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (9, N'D6dwG5b5QfLsCpTL')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (10, N'49piNgLbCag98txg')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (11, N'hmwhoNoffvOWNqqP')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (12, N'p6nYt32NVTLSAcy5')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (13, N'SONnbF9VhOTQeMkG')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (14, N'jrsqOV5Fr5ac0Bks')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (15, N'ZCMXpvaRk7tcNftr')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (16, N'QHIF1Jy8x0Dx33ND')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (17, N'eSkgUf7TGHnewoGP')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (18, N'ototObNbfEhlyMJM')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (19, N'zGr7z0f5AjRiSyYZ')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (20, N'TqAj0QA5YG9MQ6Tv')
GO
INSERT [dbo].[auto_keys] ([key_id], [key_value]) VALUES (21, N'abc456dxfdgy5754rtgdfr')
GO
SET IDENTITY_INSERT [dbo].[auto_keys] OFF
GO
SET IDENTITY_INSERT [dbo].[File_Master] ON 
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (1, N'Congress_enc1.png', N'hmwhoNoffvOWNqqP', N'Congress.png', N'8JnqJCssO1vRgB1HK8FSVfbJ/O7Wh6n8MO1s8cca8mo=', N'Lr47HC8tLY+fHOGSau2Z3A==', NULL)
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (2, N'soil_enc1.jpg', N'NZoDpCFtMvp4zh7c', N'soil.jpg', N'22cXDwwXqnJHGbIC1sUxoSqna/reopgJgOBfrqEZfYM=', N'ug3Au0mQNa+f1hZBLioD1A==', NULL)
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (3, N'data__enc1.txt', N'HhOF5M4iSBDqH9t5', N'data_.txt', N'ry2ZGmarM8P/dr846UD3qArd17i8KXNQZqRE2m51Bfc=', N'BGknGqBVGUqJ+J83KlwyxA==', NULL)
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (1003, N'wP8MQj_enc1.jpg', N'I4y8UvLFTbXxvnwz', N'wP8MQj.jpg', N'W6ani0rFlt+JlKpwZHgIsPxAdQZ24s58ZY/NKDLXZpM=', N'SNO9WJMq51Snvh8G0twjHw==', NULL)
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (2003, N'es (1)_enc1.jpg', N'hTAN4Pd4pLdbpWek', N'es (1).jpg', N'edHP+jeLi/xPoTy5aiFlvvspIhVXvpkc6Fqy65mR+Iw=', N'zYDhf8fCgs2bmiVLgEqiYA==', NULL)
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (2004, N'4_enc1.jpg', N'KezM2QyHrzSykUG8', N'4.jpg', N'UQbPlySrSbs/CTDc+hrfljcwdQiq3Pk0n4jaZ6eJim0=', N'Yq5moQkUSasaHmYaB5e4ew==', N'15f959868b351dc84f620a59527961dc5b3cf2e8364d461a5aa1d5bb8d2010fe')
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (3004, N'10_enc1.jpg', N'p6nYt32NVTLSAcy5', N'10.jpg', N'FHQVVR76/BhdGvcADnzlYwdWeHAlQxFBOlPYBZZ3pDs=', N'oCMGk/XBzZ34z/MDgsrtdA==', N'a8783fe2373eee69f8a94cc53d2f947353964ae7b3106262d510ab7c6c010d26')
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (3005, N'photo (6)_enc.jpg', N'n7B1DuiIN0m6ZxIH', N'photo (6).jpg', N'ydk8hMY+GDfptF8gQz1EcMa1S7xs/XZ5+DD+n3PQByM=', N'/iJ+HSi4QSxWwEAAYpfIWQ==', N'740fb2197f2cf602d1eac24462dc5e510548ab4066c3f200a2aa19f6a9c3338f')
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (3006, N'7_enc.jpg', N'SONnbF9VhOTQeMkG', N'7.jpg', N'6reXRoDE5+GNzOeS0n4p78DQqRY6MhC29eniZALSCxY=', N'cxGVrXqmd/u2YtwdFtZ3kw==', N'201bb1763d87089b4e0129559594d9edfa3375f6a39e45b8685743080739a807')
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (4004, N'wnload (21)_dec_enc1.jpg', N'hTAN4Pd4pLdbpWek', N'wnload (21)_dec.jpg', N'OBRmvTtYRbTaGBG2bYiDujey2cMQfFN1wY2fg1fIe9o=', N'84c4wjpyKHcy+b1qPxGfjw==', N'599472c49fd9d2284e343e5405534aeca4fef6a16afb4ad272ab40378a64f834')
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (4005, N'unnamed_enc1.jpg', N'abc456dxfdgy5754rtgdfr', N'unnamed.jpg', N'lgFEZjYAKa6aZa5Rgt/lJqp7AgyzUKZdPIGmUy+fZJY=', N'+Hld1hr2YJ0=', N'2f68181cd012b6648a62907e339475a1a20062276be2a1793d141a0b76d51dc8')
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (4006, N'Untitled_enc1.png', N'RSsXECK53QMENjwx', N'Untitled.png', N'CI/6BvV6350LryVaI6ZytiNY++k9Q2FCd8qMjP03C+0=', N'VRwecU/Hg1A=', N'b9daba7525820321ec1e8475a905d8390c45afd2df74995540dbb4aee64f8672')
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (4007, N'10_enc1.jpg', N'hmwhoNoffvOWNqqP', N'10.jpg', N'QAtF7MhUZWw=', N'wcitU1xyais=', N'a8783fe2373eee69f8a94cc53d2f947353964ae7b3106262d510ab7c6c010d26')
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (4008, N'RIC_new_enc1.docx', N'jrsqOV5Fr5ac0Bks', N'RIC_new.docx', N'ghBv2LSQclQ=', N'r6u5lXMhsCc=', N'68e03f1f4324a91ca79bf30e0ebf39f82d44085856f81fa4c444365c4e1a8515')
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (4009, N'wnload (18)_enc1.jpg', N'hmwhoNoffvOWNqqP', N'wnload (18).jpg', N'wesfZxPT8fQ8GDkORK4AQTAOISnug9vonUsN6tLIOno=', N'tf03vwqzIm6cGrq+/yWSFA==', N'979a28379f0fbfa1eaaa187529f8c71e5c93a03fcc71332edff1c6a161d344ec')
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (4010, N'F_Project_2019-2020EncryptionDecryption_AES_ECCFinal_versionFiles4_enc1_dec_enc1.jpg', N'QHIF1Jy8x0Dx33ND', N'F_Project_2019-2020EncryptionDecryption_AES_ECCFinal_versionFiles4_enc1_dec.jpg', N'YbdPHtga99I=', N'ZMsnZPotloE=', N'15f959868b351dc84f620a59527961dc5b3cf2e8364d461a5aa1d5bb8d2010fe')
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (5004, N'splash_enc1.jpg', N'TqAj0QA5YG9MQ6Tv', N'splash.jpg', N'76MztUc2JaSZzlP6YlUlU5hMH2a2z+brDabcV+0uZgY=', N'6whzH7KDtJX6LOvx7cXMMw==', N'11732b5022addbe68a0e6cdb066c6d8bbd0150cc8b444e2606c026d16e054010')
GO
INSERT [dbo].[File_Master] ([file_id], [file_path], [key_value], [file_name], [File_key], [IV], [Hash]) VALUES (5005, N'use-case_enc1.png', N'TqAj0QA5YG9MQ6Tv', N'use-case.png', N'ixFJnjqEzyGGbBjoJGRjtIX7w9Jwjm8k8xkM13VgcxI=', N'eQNoIxqDHUP8cv12lgQMQw==', N'8e391d57f63bb4562a55d0c6c6a8d670e82ee9d0ea9035dc3377a8e801cbd105')
GO
SET IDENTITY_INSERT [dbo].[File_Master] OFF
GO
SET IDENTITY_INSERT [dbo].[Share_Master] ON 
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (1, N'Congress.png', N'ankitkesarwani122@gmail.com', N'cloud', 1)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (2, N'soil.jpg', N'ankitkesarwani122@gmail.com', N'cloud', 2)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (3, N'data_.txt', N'ankitkesarwani122@gmail.com', N'cloud', 3)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (1002, N'wP8MQj.jpg', N'swapnilgurav94@gmail.com', N'cloud', 1003)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (2002, N'es (1).jpg', N'swapnilgurav94@gmail.com', N'cloud', 2003)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (2003, N'4.jpg', N'swapnilgurav94@gmail.com', N'cloud', 2004)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (3002, N'10.jpg', N'nivrutikore@gmail.com', N'cloud', 3004)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (3003, N'photo (6).jpg', N'nivrutikore@gmail.com', N'cloud', 3005)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (3004, N'7.jpg', N'nivrutikore@gmail.com', N'cloud', 3006)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (4002, N'wnload (21)_dec.jpg', N'guidance@projectideas.co.in', N'cloud', 4004)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (4003, N'unnamed.jpg', N'guidance@projectideas.co.in', N'cloud', 4005)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (4004, N'Untitled.png', N'guidance@projectideas.co.in', N'cloud', 4006)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (4005, N'10.jpg', N'guidance@projectideas.co.in', N'cloud', 3004)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (4006, N'RIC_new.docx', N'guidance@projectideas.co.in', N'cloud', 4008)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (4007, N'wnload (18).jpg', N'guidance@projectideas.co.in', N'cloud', 4009)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (4008, N'wnload (18).jpg', N'test@gmail.com', N'cloud', 4009)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (4010, N'10.jpg', N'guidance@projectideas.co.in', N'cloud', 3004)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (5002, N'splash.jpg', N'kamlishubham1@GMAIL.COM', N'cloud', 5004)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (5003, N'10.jpg', N'kamblishubham1@gmail.com', N'cloud', 3004)
GO
INSERT [dbo].[Share_Master] ([share_id], [file_name], [username], [cloud_id], [fid]) VALUES (5004, N'use-case.png', N'kamblishubham1@gmail.com', N'cloud', 5005)
GO
SET IDENTITY_INSERT [dbo].[Share_Master] OFF
GO
SET IDENTITY_INSERT [dbo].[trnOtp] ON 
GO
INSERT [dbo].[trnOtp] ([OTPID], [UserID], [OTP], [GeneratedOn], [Type]) VALUES (1, 3, 34072, CAST(N'2023-03-05T00:58:00.707' AS DateTime), 2)
GO
INSERT [dbo].[trnOtp] ([OTPID], [UserID], [OTP], [GeneratedOn], [Type]) VALUES (2, 1, 59489, CAST(N'2023-03-05T01:00:50.233' AS DateTime), 1)
GO
INSERT [dbo].[trnOtp] ([OTPID], [UserID], [OTP], [GeneratedOn], [Type]) VALUES (3, 1, 97755, CAST(N'2023-03-05T01:05:35.407' AS DateTime), 1)
GO
SET IDENTITY_INSERT [dbo].[trnOtp] OFF
GO
SET IDENTITY_INSERT [dbo].[User_Master] ON 
GO
INSERT [dbo].[User_Master] ([user_id], [full_name], [contact_no], [email_id], [address], [password]) VALUES (1, N'Nivruti B Kore', N'9632587410', N'nivrutikore@gmail.com', N'Ghansoli , New Mumbai', N'12345')
GO
INSERT [dbo].[User_Master] ([user_id], [full_name], [contact_no], [email_id], [address], [password]) VALUES (3, N'chintan', N'9892369017', N'charanbirdi10@gmail.com', N'Kandivali-west', N'654321')
GO
INSERT [dbo].[User_Master] ([user_id], [full_name], [contact_no], [email_id], [address], [password]) VALUES (4, N'maher', N'9892369017', N'tejas18mohite@gmail.com', N'Kandivali-west', N'PUi5lZbI')
GO
INSERT [dbo].[User_Master] ([user_id], [full_name], [contact_no], [email_id], [address], [password]) VALUES (5, N'ankit', N'8605973598', N'ankitkesarwani122@gmail.com', N'kandivali', N'5GOPXvkW')
GO
INSERT [dbo].[User_Master] ([user_id], [full_name], [contact_no], [email_id], [address], [password]) VALUES (6, N'swapnil', N'9892369017', N'swapnilgurav94@gmail.com', N'Kandivali west', N'123456')
GO
INSERT [dbo].[User_Master] ([user_id], [full_name], [contact_no], [email_id], [address], [password]) VALUES (9, N'sagar', N'9920365985', N'sagarwarchavan28@gmail.com', N'mumbai', N'3fg5CJtK')
GO
INSERT [dbo].[User_Master] ([user_id], [full_name], [contact_no], [email_id], [address], [password]) VALUES (8, N'test', N'9892369017', N'test@gmail.com', N'Kandivali westsss', N'y86hPcR6')
GO
INSERT [dbo].[User_Master] ([user_id], [full_name], [contact_no], [email_id], [address], [password]) VALUES (1009, N'shubham', N'9956536598', N'kamblishubham1@gmail.com', N'SDASDAS', N'XFud8JVq')
GO
SET IDENTITY_INSERT [dbo].[User_Master] OFF
GO
/****** Object:  StoredProcedure [dbo].[CompareKeys]    Script Date: 05-03-2023 20:00:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[CompareKeys]
	@key_value varchar(500)
As
BEGIN
	SET NOCOUNT ON;
	Declare @count int;
	set @count = 0;
	-- Check key id 
	
	Declare @keyValue varchar(500);
	--select @keyValue = key_id from ECC_algorithm.dbo.auto_keys where key_value = @key_value
	Select @keyValue=key_value from File_Master where key_value = @key_value
	if(@keyValue is not null)
	begin		
		begin
			select file_id, file_path,file_name from File_Master where key_value = @keyValue
		end
		
		
 	End
 	else 
 	begin
 		-- key value is wrong
 		
 		return 0;
 	end 
 	
 	 
 	
END

GO
/****** Object:  StoredProcedure [dbo].[Select_Data]    Script Date: 05-03-2023 20:00:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Select_Data]
	@file_name nvarchar(200)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	select * from File_Master where file_name=@file_name
END

GO
/****** Object:  StoredProcedure [dbo].[Select_info]    Script Date: 05-03-2023 20:00:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Select_info]
	@file_name nvarchar(200)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT * from File_Master where file_name=@file_name
END

GO
/****** Object:  StoredProcedure [dbo].[usp_VerifyOtp]    Script Date: 05-03-2023 20:00:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[usp_VerifyOtp]
(
	@UserID [int],
	@Otp [int],
	@Type [tinyint] -- 1 => Admin, 2 => User
)
as
/*
	usp_VerifyOtp 3,12345,2
*/
Begin
	set nocount on

		declare @Status [int], @Message [varchar](100)

		if exists(select top 1 1 from trnOtp where [UserID] = @UserID and [Otp] = @Otp and [Type] = @Type and datediff(minute,GeneratedOn,getdate()) <= 5)
		Begin
			select @Status = 200, @Message = 'OTP verified'
		End
		else if exists(select top 1 1 from trnOtp where [UserID] = @UserID and [Otp] = @Otp and [Type] = @Type and datediff(minute,GeneratedOn,getdate()) > 5)
		Begin
			select @Status = 409, @Message = 'OTP expired. Please login again'
		End
		else
		Begin
			select @Status = 409, @Message = 'Invalid OTP'
		End

		select @Status as [Status], @Message as [Message]
	set nocount off
End
GO
USE [master]
GO
ALTER DATABASE [ENC_DEC_AES_ECC] SET  READ_WRITE 
GO
