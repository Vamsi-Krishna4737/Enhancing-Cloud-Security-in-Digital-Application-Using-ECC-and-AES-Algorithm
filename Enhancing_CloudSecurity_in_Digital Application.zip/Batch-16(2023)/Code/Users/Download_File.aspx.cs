﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Configuration;
using System.Net;
using System.Diagnostics;

public partial class Users_Download_File : System.Web.UI.Page
{
    public string file_path, key,key_aes, fileName, fileExtension, output,output1,input_file;
    public static string cs = ConfigurationManager.ConnectionStrings["dbConnection"].ConnectionString;
    public SqlConnection conn;
    protected string time;
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            if (Session["user_id"] == "")
            {
                Response.Redirect("Login.aspx?msg=logout");
            }
        }
        
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
         conn=new SqlConnection(cs);
         

        string share_id = Request.QueryString["share_id"];
        string query = "select file_name,fid from Share_Master where share_id='" + share_id + "'";
        DataTable dt = Database.Getdata(query);

        string file_name = Convert.ToString(dt.Rows[0]["file_name"]);
        int fileid = Convert.ToInt32(dt.Rows[0]["fid"]);

        using (SqlCommand cmd = new SqlCommand("select * from file_master where file_key=@key_value", conn))
        {
            cmd.Parameters.AddWithValue("@key_value", txtsecret_key.Text);
            using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
            {
                DataTable dt1 = new DataTable();
                adp.Fill(dt1);
                if (dt1.Rows.Count > 0)
                {
                    Stopwatch objWatch = new Stopwatch();
                    objWatch.Start();

                    file_path = Convert.ToString(dt1.Rows[0]["file_path"]);
                    fileName = Path.GetFileNameWithoutExtension(file_path);
                    fileExtension = Path.GetExtension(file_path);
                    output = Server.MapPath("../Files/" + fileName + "_dec" + fileExtension);
                    output1 = Server.MapPath("../Files/" + fileName + "_dec1" + fileExtension);
                    input_file = Server.MapPath("../Files/" + file_path);
                    key = txtsecret_key.Text;
                    key_aes = Convert.ToString(dt1.Rows[0]["key_value"]);

                    Decrypt(key_aes, input_file, output);

                    StreamReader reader = File.OpenText(output);
                    string data_1 = "";
                    string line = reader.ReadLine();
                    while (line != null)
                    {
                        data_1 = data_1 + line;
                        Console.WriteLine(line);
                        line = reader.ReadLine();
                    }
                    reader.Close();

                    objWatch.Stop();
                    time = Convert.ToString(objWatch.ElapsedMilliseconds);



                    //var keyBytes = (Byte[])dt1.Rows[0]["FileKey"];
                    byte[] keyBytes = Convert.FromBase64String(key);
                    byte[] iv = Convert.FromBase64String(dt1.Rows[0]["iv"].ToString());

                    Byte[] fileBytes = Alice.Receive(File.ReadAllBytes(output), keyBytes, iv);
                    File.WriteAllBytes(output1, fileBytes.ToArray());

                    label3.Text = Convert.ToString(time) + "ms";
                    FileInfo fi = new FileInfo(output1);

                    long size = fi.Length;

                    long size_kb = size / 1024;

                    label4.Text = Convert.ToString(size_kb) + "KB";
                    // Create a new file   



                    //HttpResponse req = HttpContext.Current.Response;
                    //req.AddHeader("Content-Disposition",
                    //    "attachment;filename=\"" + output + "\"");
                    //req.BinaryWrite(fileBytes);
                    //req.End();

                    // Alert.Show("File Decrypted Successfully. Decryption Time : " + time + "ms");
                }
                else {
                    Alert.Show("INVALID KEY!!");
                }
            }
        }



    }

    private void Decrypt(string key, string inputFilePath, string outputfilePath)
            {
                string EncryptionKey = key;
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (FileStream fsInput = new FileStream(inputFilePath, FileMode.Open))
                    {
                        using (CryptoStream cs = new CryptoStream(fsInput, encryptor.CreateDecryptor(), CryptoStreamMode.Read))
                        {
                            using (FileStream fsOutput = new FileStream(outputfilePath, FileMode.Create))
                            {
                                int data;
                                while ((data = cs.ReadByte()) != -1)
                                {
                                    fsOutput.WriteByte((byte)data);

                                    
                                }
                            }
                        }
                    }
                }
            }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        conn = new SqlConnection(cs);


        string share_id = Request.QueryString["share_id"];
        string query = "select file_name,fid from Share_Master where share_id='" + share_id + "'";
        DataTable dt = Database.Getdata(query);

        string file_name = Convert.ToString(dt.Rows[0]["file_name"]);
        int fileid = Convert.ToInt32(dt.Rows[0]["fid"]);

        using (SqlCommand cmd = new SqlCommand("select * from file_master where file_key=@key_value", conn))
        {
            cmd.Parameters.AddWithValue("@key_value", txtsecret_key.Text);
            using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
            {
                DataTable dt1 = new DataTable();
                adp.Fill(dt1);
                if (dt1.Rows.Count > 0)
                {
                    

                    file_path = Convert.ToString(dt1.Rows[0]["file_path"]);
                    fileName = Path.GetFileNameWithoutExtension(file_path);
                    fileExtension = Path.GetExtension(file_path);
                    output = Server.MapPath("../Files/" + fileName + "_dec" + fileExtension);
                    output1 = Server.MapPath("../Files/" + fileName + "_dec1" + fileExtension);
                    input_file = Server.MapPath("../Files/" + file_path);
                    key = txtsecret_key.Text;
                    key_aes = Convert.ToString(dt1.Rows[0]["key_value"]);

                    Decrypt(key_aes, input_file, output);

                    StreamReader reader = File.OpenText(output);
                    string data_1 = "";
                    string line = reader.ReadLine();
                    while (line != null)
                    {
                        data_1 = data_1 + line;
                        Console.WriteLine(line);
                        line = reader.ReadLine();
                    }
                    reader.Close();

                   

                    

                    //var keyBytes = (Byte[])dt1.Rows[0]["FileKey"];
                    byte[] keyBytes = Convert.FromBase64String(key);
                    byte[] iv = Convert.FromBase64String(dt1.Rows[0]["iv"].ToString());

                    Byte[] fileBytes = Alice.Receive(File.ReadAllBytes(output), keyBytes, iv);



                    HttpResponse req = HttpContext.Current.Response;
                    req.AddHeader("Content-Disposition",
                        "attachment;filename=\"" + output + "\"");
                    req.BinaryWrite(fileBytes);
                    req.End();

                    
                }
                else
                {
                    Alert.Show("INVALID KEY!!");
                }
            }
        }
    }
}